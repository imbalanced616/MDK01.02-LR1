﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System;
using ClassLibraryFormula;

namespace UnitTestProjectFormula
{
    [TestClass]
    public class UnitTestFormula
    {
        [TestMethod]
        public void R1_Formula_07and05and005__6_63130314222938returned()
        {
            double a = 0.7;
            double x = 0.5;
            double b = 0.05;
            double expected = 6.63130;

            ClassFormula R = new ClassFormula();
            double actual = R.FormulaR(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void S1_Formula_07and05and005__0915780297217402returned()
        {
            double a = 0.7;
            double x = 0.5;
            double b = 0.05;
            double expected = 0.91578;

            ClassFormula S = new ClassFormula();
            double actual = S.FormulaS(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void R2_Formula_0and0and1__0returned()
        {
            double a = 0;
            double x = 0;
            double b = 1;
            double expected = 0;

            ClassFormula R = new ClassFormula();
            double actual = R.FormulaR(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void S2_Formula_1and0and0__1returned()
        {
            double a = 1;
            double x = 0;
            double b = 0;
            double expected = 1;

            ClassFormula S = new ClassFormula();
            double actual = S.FormulaS(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void R3_Formula_1and1and1__1returned()
        {
            double a = 1;
            double x = 1;
            double b = 1;
            double expected = 1.17318;

            ClassFormula R = new ClassFormula();
            double actual = R.FormulaR(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void S3_Formula_1and1and1__1returned()
        {
            double a = 1;
            double x = 1;
            double b = 1;
            double expected = 1.17318;

            ClassFormula S = new ClassFormula();
            double actual = S.FormulaS(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void R4_Formula_minus07andminus05andminus005__minus3_3687returned()
        {
            double a = -0.7;
            double x = -0.5;
            double b = -0.05;
            double expected = -3.3687;

            ClassFormula R = new ClassFormula();
            double actual = R.FormulaR(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void S4_Formula_minus07andminus05andminus005__0_99979returned()
        {
            double a = -0.7;
            double x = 0.5;
            double b = -0.05;
            double expected = 0.99979;

            ClassFormula S = new ClassFormula();
            double actual = S.FormulaS(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void R5_Formula_30and50and60__2124_01219returned()
        {
            double a = 30;
            double x = 50;
            double b = 60;
            double expected = 2124.01219;

            ClassFormula R = new ClassFormula();
            double actual = R.FormulaR(a, x, b);

            Assert.AreEqual(expected, actual);
        }

        [TestMethod]
        public void S5_Formula_30and50and60__10_99804returned()
        {
            double a = 30;
            double x = 50;
            double b = 60;
            double expected = 10.99804;

            ClassFormula S = new ClassFormula();
            double actual = S.FormulaS(a, x, b);

            Assert.AreEqual(expected, actual);
        }
    }
}
